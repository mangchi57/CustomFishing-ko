1.Custom Crops 2.itemsAdder 파일이 있습니다 

해당 파일은

1번 파일은 기존 플러그인 폴더에 넣어서 적용하시고

2번은 ItemsAdder cotents 경로 에 넣으시면 적용 됩니다.

